<?php
$prenom =  $_GET['prenom'];


function searchPrenom($employe)  
{
    try {
        $prenom = $employe->getPrenom();

        $connexion = new Connexion();
        $db = $connexion->connexion();
        $query = "SELECT FROM employe WHERE prenom LIKE %$prenom";
        $stmt = $db->prepare($query);

        if ($stmt === false) {
            printf("Message d'erreur : %s\n", $db->error);
        die();
        }
        $stmt->bind_param('s', $prenom);
        $stmt->execute();

        $rs = $stmt->get_result();
        $searchPrenom = $rs->fetch_all(MYSQLI_ASSOC);

        $rs->free();
        $db->close(); 

        $tabPrenom = array();
        $i=1;
        foreach ($tabPrenom as $value) { 
            $tabPrenomRet = new Employe();
            $tabPrenomRet->setPrenom($value['prenom']);
            $tabPrenom[$i]=$tabPrenomRet->getSup();
            $i++;  
        }
        return $tabPrenom;
    }
    catch (mysqli_sql_exception $e) {
        throw new DAOException($e->getMessage(), $e->getCode());
    }
}

function searchNom($employe)  
{
    try {
        $nom = $employe->getNom();

        $connexion = new Connexion();
        $db = $connexion->connexion();
        $query = "SELECT FROM employe WHERE nom LIKE %$nom";
        $stmt = $db->prepare($query);

        if ($stmt === false) {
            printf("Message d'erreur : %s\n", $db->error);
        die();
        }
        $stmt->bind_param('s', $nom);
        $stmt->execute();
    
        $db->close(); 
    }
    catch (mysqli_sql_exception $e) {
        throw new DAOException($e->getMessage(), $e->getCode());
    }
}    

function searchEmploi($employe)  
{
    try {
        $emploi = $employe->getEmploi();

        $connexion = new Connexion();
        $db = $connexion->connexion();
        $query = "SELECT FROM employe WHERE emploi LIKE %$emploi";
        $stmt = $db->prepare($query);

        if ($stmt === false) {
            printf("Message d'erreur : %s\n", $db->error);
        die();
        }
        $stmt->bind_param('s', $emploi);
        $stmt->execute();
    
        $db->close(); 
    }
    catch (mysqli_sql_exception $e) {
        throw new DAOException($e->getMessage(), $e->getCode());
    }
}   

function searchNoserv($employe)  
{
    try {
        $noserv = $employe->getNoserv();

        $connexion = new Connexion();
        $db = $connexion->connexion();
        $query = "SELECT FROM employe WHERE noserv LIKE %$noserv";
        $stmt = $db->prepare($query);

        if ($stmt === false) {
            printf("Message d'erreur : %s\n", $db->error);
        die();
        }
        $stmt->bind_param('i', $noserv);
        $stmt->execute();
    
        $db->close(); 
    }
    catch (mysqli_sql_exception $e) {
        throw new DAOException($e->getMessage(), $e->getCode());
    }
}   

