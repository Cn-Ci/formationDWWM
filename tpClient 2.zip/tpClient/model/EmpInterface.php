<?php 
include_once ("InterfaceDAO.php");

interface EmpInterface extends InterfaceDAO
{
    function SupOne();
}