<?php 

include_once('../model/Employe.php');
include_once('../presentation/empIndex.php');
include_once('../model/EmpService.php');

$search = EmpService::research();
$employeRet = filter_by_value($tabResearch, $tabResearch['nom'], $key_to_search);

echo json_encode($employeRet);


function filter_by_value ($array, $index, $value){
    if(is_array($array) && count($array)>0) 
    {
        foreach(array_keys($array) as $key){
            $temp[$key] = $array[$key][$index];
            
            if ($temp[$key] == $value){
                $newarray[$key] = $array[$key];
            }
        }
      }
  return $newarray;
}