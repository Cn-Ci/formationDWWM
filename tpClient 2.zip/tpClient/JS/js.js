$( "#prenom" ).keyup(function() {

    var prenom = $(this).val()
    $.ajax({
                url: "../presentation/infosAjax.php",
                type: "GET",
                data : "prenom=" + prenom,
                dataType: "json",
                minLength: 1,
                success : function(resultat, statut){
                console.log(resultat);
                }
        });
})

$( "#nom" ).keyup(function() {

    var nom = $(this).val()
    $.ajax({
                url: "../presentation/infosAjax.php",
                type: "GET",
                data : "nom=" + nom,
                dataType: "json",
                minLength: 1,
                success : function(resultat, statut){
                console.log(resultat);
                }
        });
})

$( "#emploi" ).keyup(function() {

    var emploi = $(this).val()
    $.ajax({
                url: "../presentation/infosAjax.php",
                type: "GET",
                data : "emploi=" + emploi,
                dataType: "json",
                minLength: 1,
                success : function(resultat, statut){
                console.log(resultat);
                }
        });
})

$( "#noserv" ).keyup(function() {

    var noserv = $(this).val()
    $.ajax({
                url: "../presentation/infosAjax.php",
                type: "GET",
                data : "noserv=" + noserv,
                dataType: "json",
                minLength: 1,
                success : function(resultat, statut){
                console.log(resultat);
                }
        });
})