<?php 

class ServiceException extends Exception {
    
}