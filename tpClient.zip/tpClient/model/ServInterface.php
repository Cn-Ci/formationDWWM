<?php 
include_once ("InterfaceDAO.php");

interface ServInterface extends InterfaceDAO
{
    function supOne();
}